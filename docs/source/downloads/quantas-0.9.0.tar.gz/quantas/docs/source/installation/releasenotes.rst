.. _releasenotes:

=============
Release notes
=============


Version 0.9.0
-------------

01 March 2020: 0.9.0.

  - Initial release of Quantas (beta)


