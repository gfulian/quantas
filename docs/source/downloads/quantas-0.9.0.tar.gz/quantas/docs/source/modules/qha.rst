.. module:: quantas.qha
.. index:: Quasi-Harmonic Approximation

============================
Quasi-Harmonic Approximation
============================

.. autoclass:: quantas.qha.qha.QHACalculator
   :show-inheritance:
   :members:
