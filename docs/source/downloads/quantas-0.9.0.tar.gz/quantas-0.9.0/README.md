# README
#
# Quantas (QUANTitative Analysis of Solids) is a software 
# developed to aid the analysis of data obtained from (ab initio) 
# quantum mechanical simulations and/or experiments. 
# It is a cross-platform program coded in Python 3.x. 
#
# Copyright (c) 2020, Gianfranco Ulian
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# * Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in the
#   documentation and/or other materials provided with the distribution.
# * Neither the name of the Quantas project nor the
#   names of its contributors may be used to endorse or promote products
#   derived from this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL GIANFRANCO ULIAN 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# 
Requirements
------------
- Python_ 3.4-3.6
- NumPy_ (base N-dimensional array package)
- SciPy_ (library for scientific computing)


.. _Python: http://www.python.org/
.. _NumPy: http://docs.scipy.org/doc/numpy/reference/
.. _SciPy: http://docs.scipy.org/doc/scipy/reference/


Installation using pip
----------------------

The simplest way to install Quantas is to use pip on the pre-built Python wheel.
This will install Quantas in a local folder where Python can automatically find it 
(for example, ``~/.local`` on Unix). Quantas Command Line Tool will be installed in 
the following location, according to the OS:

Unix and Mac OSX     ``~/.local/bin``
Homebrew             ``~/Library/Python/X.Y/bin``
Windows              ``%APPDATA%/Python/Scripts``

Make sure you have that path in your :envvar:`PATH` environment variable.

Note: If your OS doesn't have ``numpy`` and ``scipy`` packages installed, 
you can install them with::

        $ pip install --upgrade --user numpy scipy matplotlib

Note: On Windows, you could benefit from the Unofficial Windows Binaries 
    made available Christoph Gohlke, in particular:

    - Numpy+MKL_
    - Scipy_Numpy+MKL_

The wheels can be downloaded from https://www.lfd.uci.edu/%7Egohlke/pythonlibs/
After downloading the package wheels, you can install them using ``pip``.


.. _link: http://www.lfd.uci.edu/~gohlke/pythonlibs/
.. _Numpy+MKL: http://www.lfd.uci.edu/~gohlke/pythonlibs/#numpy
.. _Scipy_Numpy+MKL: http://www.lfd.uci.edu/~gohlke/pythonlibs/#scipy

Installation from source
------------------------

1) Unpack the compressed file and enter in the decompressed directory:

:Linux:

    On a shell::
        
        $ tar -xf Quantas-0.9.0.tar.gz
        $ cd Quantas-0.9.0


:Mac OS X:

    On a shell::
        
        $ tar -xf Quantas-0.9.0.tar.gz
        $ cd Quantas-0.9.0


:Windows:

    Use a software as 7zip or WinRar to decompress the file.

2) Install the Quantas package:

:Linux:

    On a shell::
        
        $ python3 setup.py install

:Mac OS X:

    On a shell::
        
        $ python3 setup.py install

:Windows:

    On a command prompt::
        
        $ python3 setup.py install


Test Quantas installation
-------------------------

Some input examples are available to test the installation of Quantas. 
Unpack them in any folder you like.

Before running the tests, make sure you have set your PATH.

Run the tests like::

    $ Quantas examples\corundum.td

If something goes wrong, please send us an output log of the failing test.